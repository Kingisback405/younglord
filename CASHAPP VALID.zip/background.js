// Background service worker for Email Validator Pro

// Open extension in new tab when icon clicked
chrome.action.onClicked.addListener(async () => {
  const extensionUrl = chrome.runtime.getURL('app.html');
  
  // Check if extension tab already open
  const tabs = await chrome.tabs.query({});
  const existingTab = tabs.find(tab => tab.url === extensionUrl);
  
  if (existingTab) {
    // Focus existing tab instead of opening new one
    await chrome.tabs.update(existingTab.id, { active: true });
    await chrome.windows.update(existingTab.windowId, { focused: true });
  } else {
    // Create new tab
    chrome.tabs.create({
      url: extensionUrl
    });
  }
});

// Listen for messages from extension tab
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'validateEmail') {
    handleValidateEmail(request.config)
      .then(response => sendResponse(response))
      .catch(error => sendResponse({ error: error.message }));
    return true; // Keep the message channel open for async response
  }
  
  if (request.action === 'openTargetTab') {
    handleOpenTargetTab(request.url)
      .then(response => sendResponse(response))
      .catch(error => sendResponse({ error: error.message }));
    return true;
  }
});

// Handle email validation request
async function handleValidateEmail(config) {
  try {
    const options = {
      method: config.method,
      headers: {
        'Content-Type': 'application/json',
        ...config.headers
      }
    };
    
    // Add body for POST/PUT requests
    if (config.method === 'POST' || config.method === 'PUT') {
      options.body = config.body;
    }
    
    // Make the fetch request (direct connection)
    const startTime = Date.now();
    const response = await fetch(config.url, options);
    const endTime = Date.now();
    
    // Get response headers
    const headers = {};
    response.headers.forEach((value, key) => {
      headers[key] = value;
    });
    
    // Get response body
    let data;
    const contentType = response.headers.get('content-type');
    
    if (contentType && contentType.includes('application/json')) {
      try {
        data = await response.json();
      } catch (e) {
        data = await response.text();
      }
    } else {
      data = await response.text();
    }
    
    // Return formatted response
    return {
      status: response.status,
      statusText: response.statusText,
      headers: headers,
      data: data,
      email: config.email,
      time: endTime - startTime,
      error: null
    };
    
  } catch (error) {
    console.error('Validation error:', error);
    return {
      status: 0,
      statusText: 'Error',
      headers: {},
      data: null,
      email: config.email,
      time: 0,
      error: error.message
    };
  }
}

// Installation handler
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('Email Validator Pro installed successfully!');
  } else if (details.reason === 'update') {
    console.log('Email Validator Pro updated to version', chrome.runtime.getManifest().version);
  }
});

// Handle opening target tab
async function handleOpenTargetTab(url) {
  try {
    if (!url) {
      throw new Error('URL is required');
    }
    
    // Check if tab with this URL already exists
    const tabs = await chrome.tabs.query({});
    const existingTab = tabs.find(tab => tab.url && tab.url.startsWith(url));
    
    if (existingTab) {
      // Focus existing tab
      await chrome.tabs.update(existingTab.id, { active: true });
      await chrome.windows.update(existingTab.windowId, { focused: true });
      return { success: true, action: 'focused', tabId: existingTab.id };
    } else {
      // Create new tab
      const newTab = await chrome.tabs.create({
        url: url,
        active: true
      });
      return { success: true, action: 'created', tabId: newTab.id };
    }
  } catch (error) {
    console.error('Error opening target tab:', error);
    return { success: false, error: error.message };
  }
}

// Keep service worker alive (optional, for long-running operations)
let keepAliveInterval;

function keepAlive() {
  if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
  }
  
  keepAliveInterval = setInterval(() => {
    chrome.runtime.getPlatformInfo(() => {
      // Just a dummy call to keep the service worker alive
    });
  }, 20000); // Every 20 seconds
}

keepAlive();

