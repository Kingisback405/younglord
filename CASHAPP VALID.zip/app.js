// Global variables
let emailList = [];
let currentIndex = 0;
let isRunning = false;
let validEmails = [];
let invalidEmails = [];
let liveEmails = [];
let bounceEmails = [];
let dieEmails = [];
let liveEmailsData = []; // Store email + extracted data
let latestResponse = null;
let currentConfig = null;

// DOM Elements - Config Setup
const configElements = {
  configSetup: document.getElementById('configSetup'),
  mainApp: document.getElementById('mainApp'),
  tabPasteConfig: document.getElementById('tabPasteConfig'),
  tabNewConfig: document.getElementById('tabNewConfig'),
  tabCurl: document.getElementById('tabCurl'),
  pasteConfigTab: document.getElementById('pasteConfigTab'),
  newConfigTab: document.getElementById('newConfigTab'),
  curlTab: document.getElementById('curlTab'),
  configFile: document.getElementById('configFile'),
  configText: document.getElementById('configText'),
  loadConfigBtn: document.getElementById('loadConfigBtn'),
  autoFillBtn: document.getElementById('autoFillBtn'),
  configName: document.getElementById('configName'),
  targetUrl2: document.getElementById('targetUrl2'),
  requestMethod2: document.getElementById('requestMethod2'),
  createConfigBtn: document.getElementById('createConfigBtn'),
  curlCommand: document.getElementById('curlCommand'),
  importCurlBtn: document.getElementById('importCurlBtn'),
  configStatus: document.getElementById('configStatus'),
  currentConfigInfo: document.getElementById('currentConfigInfo'),
  changeConfigBtn: document.getElementById('changeConfigBtn'),
  exportConfigBtn: document.getElementById('exportConfigBtn')
};

// Storage for extracted values
let extractedValues = {};

// DOM Elements - Main App
const elements = {
  targetUrl: document.getElementById('targetUrl'),
  openTargetBtn: document.getElementById('openTargetBtn'),
  tabPasteEmails: document.getElementById('tabPasteEmails'),
  tabUploadFile: document.getElementById('tabUploadFile'),
  pasteEmailsArea: document.getElementById('pasteEmailsArea'),
  uploadFileArea: document.getElementById('uploadFileArea'),
  emailListText: document.getElementById('emailListText'),
  loadEmailsBtn: document.getElementById('loadEmailsBtn'),
  fileUpload: document.getElementById('fileUpload'),
  fileInfo: document.getElementById('fileInfo'),
  useProxy: document.getElementById('useProxy'),
  proxySettings: document.getElementById('proxySettings'),
  proxyHost: document.getElementById('proxyHost'),
  proxyPort: document.getElementById('proxyPort'),
  proxyUser: document.getElementById('proxyUser'),
  proxyPass: document.getElementById('proxyPass'),
  useCookies: document.getElementById('useCookies'),
  getCookiesBtn: document.getElementById('getCookiesBtn'),
  refreshCookiesBtn: document.getElementById('refreshCookiesBtn'),
  cookieValue: document.getElementById('cookieValue'),
  cookieStatus: document.getElementById('cookieStatus'),
  customHeaders: document.getElementById('customHeaders'),
  requestMethod: document.getElementById('requestMethod'),
  requestBody: document.getElementById('requestBody'),
  startBtn: document.getElementById('startBtn'),
  stopBtn: document.getElementById('stopBtn'),
  progressFill: document.getElementById('progressFill'),
  progressText: document.getElementById('progressText'),
  totalCount: document.getElementById('totalCount'),
  validCount: document.getElementById('validCount'),
  invalidCount: document.getElementById('invalidCount'),
  liveCount: document.getElementById('liveCount'),
  bounceCount: document.getElementById('bounceCount'),
  dieCount: document.getElementById('dieCount'),
  results: document.getElementById('results'),
  responseContent: document.getElementById('responseContent'),
  exportValid: document.getElementById('exportValid'),
  exportInvalid: document.getElementById('exportInvalid')
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  setupConfigListeners();
  checkAndLoadConfig();
  setupEventListeners();
  setupHelpButton();
  setupNotificationSystem();
  
  // Show notification that this is tab mode
  console.log('📑 Email Validator Pro - TAB MODE');
  console.log('✓ No popup close issues!');
  console.log('✓ Full workspace available!');
  
  // Welcome notification
  showNotification('👋 Email Validator Pro loaded! Upload config to start.', 'info', 3000);
});

// Setup notification system
function setupNotificationSystem() {
  const closeBtn = document.getElementById('notificationClose');
  if (closeBtn) {
    closeBtn.addEventListener('click', hideNotification);
  }
}

// Show notification (replaces alert)
function showNotification(message, type = 'info', duration = 5000) {
  const notification = document.getElementById('notification');
  const notificationText = document.getElementById('notificationText');
  
  if (!notification || !notificationText) return;
  
  notificationText.textContent = message;
  notification.className = `notification ${type}`;
  notification.classList.remove('hidden');
  
  // Auto-hide after duration
  if (duration > 0) {
    setTimeout(() => {
      hideNotification();
    }, duration);
  }
}

// Hide notification
function hideNotification() {
  const notification = document.getElementById('notification');
  if (notification) {
    notification.classList.add('hidden');
  }
}

// Setup help button
function setupHelpButton() {
  const helpBtn = document.getElementById('helpBtn');
  if (helpBtn) {
    helpBtn.addEventListener('click', showHelp);
  }
}

// Show help dialog
function showHelp() {
  console.log('=== EMAIL VALIDATOR PRO - HELP ===');
  console.log('1. Upload .child config file');
  console.log('2. Paste email list');
  console.log('3. Start validation');
  console.log('4. Export results');
  console.log('Check documentation files for details!');
  console.log('==================================');
  
  showNotification('📚 Help logged to Console (F12)\n\nQuick: Upload config → Paste emails → Start → Export!\n\nDocs: Check .md files in folder', 'info', 8000);
}

// Check if config exists and load it
async function checkAndLoadConfig() {
  try {
    const result = await chrome.storage.local.get(['activeConfig']);
    if (result.activeConfig) {
      currentConfig = result.activeConfig;
      applyConfig(currentConfig);
      showMainApp();
      
      // Auto-open target website if enabled
      if ((currentConfig.autoRefresh || currentConfig.cookieAuto) && currentConfig.url) {
        console.log('🔗 Auto-opening target website...');
        
        const urlObj = new URL(currentConfig.url);
        const baseUrl = `${urlObj.protocol}//${urlObj.hostname}`;
        
        await chrome.runtime.sendMessage({
          action: 'openTargetTab',
          url: baseUrl
        });
        
        await sleep(1000);
        console.log('✓ Target website opened');
      }
    } else {
      showConfigSetup();
    }
  } catch (error) {
    console.error('Error loading config:', error);
    showConfigSetup();
  }
}

// Setup config tab listeners
function setupConfigListeners() {
  // Config upload only
  configElements.configFile?.addEventListener('change', loadConfigFromFile);
  configElements.changeConfigBtn?.addEventListener('click', showConfigSetup);
  configElements.exportConfigBtn?.addEventListener('click', exportCurrentConfig);
  
  // Debug button
  const viewResponseBtn = document.getElementById('viewResponseBtn');
  if (viewResponseBtn) {
    viewResponseBtn.addEventListener('click', showDebugInfo);
  }
  
  // Clear storage button
  const clearStorageBtn = document.getElementById('clearStorageBtn');
  if (clearStorageBtn) {
    clearStorageBtn.addEventListener('click', clearConfigStorage);
  }
}

// Clear config storage
async function clearConfigStorage() {
  showNotification('🗑️ Clearing storage...', 'info', 2000);
  
  try {
    await chrome.storage.local.clear();
    showNotification('✅ Storage cleared! Reloading...', 'success', 2000);
    console.log('✓ Chrome storage cleared');
    
    // Reload page to reset
    setTimeout(() => {
      location.reload();
    }, 1000);
  } catch (error) {
    console.error('Error clearing storage:', error);
    showNotification('❌ Error clearing storage: ' + error.message, 'error');
  }
}

// Show debug info
function showDebugInfo() {
  if (!latestResponse) {
    showNotification('⚠️ No response yet. Run validation first!', 'warning');
    return;
  }
  
  // Log to console (better for debugging)
  console.log('=== DEBUG INFO ===');
  console.log('Status:', latestResponse.status, latestResponse.statusText);
  console.log('Response Data:', latestResponse.data);
  console.log('Config Rules:', currentConfig?.validRules);
  console.log('Extracted Values:', extractedValues);
  console.log('==================');
  
  // Show notification
  const responsePreview = typeof latestResponse.data === 'string' ? 
    latestResponse.data.substring(0, 200) : 
    JSON.stringify(latestResponse.data).substring(0, 200);
  
  showNotification(`🔍 Debug info logged to Console (F12)\n\nStatus: ${latestResponse.status}\nPreview: ${responsePreview}...`, 'info', 8000);
}

// Switch between config tabs
function switchTab(tab) {
  // Reset tab buttons
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(content => content.classList.add('hidden'));
  
  // Activate selected tab
  if (tab === 'paste') {
    configElements.tabPasteConfig.classList.add('active');
    configElements.pasteConfigTab.classList.remove('hidden');
  } else if (tab === 'new') {
    configElements.tabNewConfig.classList.add('active');
    configElements.newConfigTab.classList.remove('hidden');
  } else if (tab === 'curl') {
    configElements.tabCurl.classList.add('active');
    configElements.curlTab.classList.remove('hidden');
  }
}

// Load config from uploaded file
async function loadConfigFromFile(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  // Extract filename without extension
  const fileName = file.name.replace('.child', '').replace(/[^a-zA-Z0-9-_]/g, ' ');
  
  const reader = new FileReader();
  reader.onload = async (e) => {
    const content = e.target.result;
    await parseAndLoadChildConfig(content, fileName);
  };
  reader.readAsText(file);
}

// Load config from text
async function loadConfigFromText() {
  const content = configElements.configText?.value.trim();
  if (!content) {
    showConfigStatus('Please paste config content or upload .child file', 'error');
    return;
  }
  await parseAndLoadChildConfig(content, null);
}

// Parse .child format config
async function parseAndLoadChildConfig(content, fileName = null) {
  try {
    const config = parseChildFormat(content);
    
    // Use filename as config name if NAME not in file
    if (fileName && (!config.name || config.name === 'Unnamed Config')) {
      config.name = fileName.charAt(0).toUpperCase() + fileName.slice(1);
      console.log('✓ Using filename as config name:', config.name);
    }
    
    // Validate config
    if (!config.url) {
      throw new Error('Config must have URL field');
    }
    
    // Save config
    currentConfig = config;
    await chrome.storage.local.set({ activeConfig: config });
    
    // Apply and show
    applyConfig(config);
    showMainApp();
    showConfigStatus(`✓ Config "${config.name}" loaded successfully!`, 'success');
    
    // Auto-open target website if enabled
    if (config.autoRefresh || config.cookieAuto) {
      showConfigStatus('🔗 Auto-opening target website...', 'info');
      
      // Extract base URL and open
      const urlObj = new URL(config.url);
      const baseUrl = `${urlObj.protocol}//${urlObj.hostname}`;
      
      await chrome.runtime.sendMessage({
        action: 'openTargetTab',
        url: baseUrl
      });
      
      await sleep(2000);
      showConfigStatus('✓ Target website opened!', 'success');
    }
    
  } catch (error) {
    console.error('Error loading config:', error);
    showConfigStatus('Error: ' + error.message, 'error');
  }
}

// Parse .child format to config object
function parseChildFormat(content) {
  const lines = content.split('\n');
  const config = {
    name: 'Unnamed Config',
    url: '',
    method: 'POST',
    headers: {},
    cookies: '',
    cookieAuto: false,
    body: '',
    extractRules: {},
    validRules: {},
    createdAt: new Date().toISOString()
  };
  
  for (let line of lines) {
    line = line.trim();
    
    // Skip comments and empty lines
    if (!line || line.startsWith('#')) continue;
    
    const colonIndex = line.indexOf(':');
    if (colonIndex === -1) continue;
    
    const key = line.substring(0, colonIndex).trim();
    const value = line.substring(colonIndex + 1).trim();
    
    // Parse different keys
    if (key === 'NAME') {
      config.name = value;
    } else if (key === 'URL') {
      config.url = value;
    } else if (key === 'METHOD') {
      config.method = value.toUpperCase();
    } else if (key === 'CONTENT_TYPE') {
      config.headers['Content-Type'] = value;
    } else if (key.startsWith('HEADER_')) {
      const headerName = key.substring(7);
      config.headers[headerName] = value;
    } else if (key === 'COOKIE_AUTO') {
      config.cookieAuto = value.toLowerCase() === 'true';
    } else if (key === 'AUTO_REFRESH') {
      config.autoRefresh = value.toLowerCase() === 'true';
    } else if (key === 'BATCH_SIZE') {
      config.batchSize = parseInt(value) || 5;
    } else if (key === 'PROXY_URL') {
      config.proxyUrl = value;
      config.proxy = parseProxyUrl(value);
    } else if (key === 'DATARAW') {
      config.body = value;
    } else if (key.startsWith('EXTRACT_')) {
      const varName = key.substring(8);
      config.extractRules[varName] = value;
    } else if (key === 'VALID_IF_STATUS') {
      config.validRules.statusRange = value;
    } else if (key === 'VALID_IF_CONTAINS') {
      config.validRules.validContains = value.split(',').map(s => s.trim());
    } else if (key === 'INVALID_IF_CONTAINS') {
      config.validRules.invalidContains = value.split(',').map(s => s.trim());
    } else if (key === 'DIE_IF_CONTAINS') {
      config.validRules.dieContains = value.split(',').map(s => s.trim());
    } else if (key === 'BOUNCE_IF_CONTAINS') {
      config.validRules.bounceContains = value.split(',').map(s => s.trim());
    } else if (key === 'LIVE_IF_CONTAINS') {
      config.validRules.liveContains = value.split(',').map(s => s.trim());
    }
  }
  
  // Auto-add user-agent and common browser headers
  if (!config.headers['user-agent'] && !config.headers['User-Agent']) {
    config.headers['User-Agent'] = navigator.userAgent;
  }
  
  return config;
}

// Auto-fill from current tab
async function autoFillFromCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url) {
      console.log('No active tab found');
      return;
    }
    
    const url = new URL(tab.url);
    
    // Auto-get cookies
    const cookies = await chrome.cookies.getAll({ domain: url.hostname });
    if (cookies.length > 0) {
      const cookieString = cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
      if (elements.cookieValue) {
        elements.cookieValue.value = cookieString;
        elements.useCookies.checked = true;
      }
      console.log(`Auto-filled ${cookies.length} cookies from ${url.hostname}`);
    }
    
    // Try to get headers from recent requests (limited by extension capabilities)
    // Note: Chrome extensions can't directly read headers from arbitrary requests
    // But we can provide common headers template
    if (elements.customHeaders && !elements.customHeaders.value) {
      const commonHeaders = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "User-Agent": navigator.userAgent,
        "Origin": url.origin,
        "Referer": tab.url
      };
      elements.customHeaders.value = JSON.stringify(commonHeaders, null, 2);
    }
    
  } catch (error) {
    console.error('Error auto-filling:', error);
  }
}

// Auto-open target website and get cookies
async function autoOpenAndGetCookies(targetUrl) {
  try {
    // Extract base URL
    const urlObj = new URL(targetUrl);
    const baseUrl = `${urlObj.protocol}//${urlObj.hostname}`;
    
    // Open target website in new tab
    const response = await chrome.runtime.sendMessage({
      action: 'openTargetTab',
      url: baseUrl
    });
    
    if (!response.success) {
      console.error('Failed to open target tab:', response.error);
      showConfigStatus('⚠️ Failed to open target website', 'warning');
      return;
    }
    
    console.log(`✓ Opened target website: ${baseUrl}`);
    
    // Wait for page to load and cookies to be set
    await sleep(3000); // Wait 3 seconds
    
    // Get cookies from the domain
    const hostname = urlObj.hostname;
    const cookies = await chrome.cookies.getAll({ domain: hostname });
    
    if (cookies.length === 0) {
      // No cookies yet, show instruction
      showConfigStatus('⚠️ Target website opened. Please LOGIN to generate cookies!', 'warning');
      
      // Set up periodic check for cookies
      let checkCount = 0;
      const cookieCheckInterval = setInterval(async () => {
        checkCount++;
        const newCookies = await chrome.cookies.getAll({ domain: hostname });
        
        if (newCookies.length > 0) {
          // Cookies found!
          clearInterval(cookieCheckInterval);
          const cookieString = newCookies.map(c => `${c.name}=${c.value}`).join('; ');
          if (elements.cookieValue) {
            elements.cookieValue.value = cookieString;
            elements.useCookies.checked = true;
          }
          showCookieStatus(`✓ Auto-loaded ${newCookies.length} cookies from ${hostname}!`, 'success');
          console.log(`✓ Auto-loaded ${newCookies.length} cookies`);
        }
        
        // Stop checking after 30 seconds (6 checks * 5 sec)
        if (checkCount >= 6) {
          clearInterval(cookieCheckInterval);
          console.log('Cookie check timeout. Please login and click "Get Cookies" manually.');
        }
      }, 5000); // Check every 5 seconds
      
    } else {
      // Cookies already exist
      const cookieString = cookies.map(c => `${c.name}=${c.value}`).join('; ');
      if (elements.cookieValue) {
        elements.cookieValue.value = cookieString;
        elements.useCookies.checked = true;
      }
      
      showCookieStatus(`✓ Auto-loaded ${cookies.length} cookies from ${hostname}!`, 'success');
      console.log(`✓ Auto-loaded ${cookies.length} cookies from ${hostname}`);
    }
    
  } catch (error) {
    console.error('Error auto-opening and getting cookies:', error);
    showConfigStatus('Error: ' + error.message, 'error');
  }
}

// Create new config
async function createNewConfig() {
  try {
    const name = configElements.configName.value.trim();
    const url = configElements.targetUrl2.value.trim();
    const method = configElements.requestMethod2.value;
    
    if (!name || !url) {
      showConfigStatus('Please fill in all fields', 'error');
      return;
    }
    
    // Auto-fill from current tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    let cookies = '';
    let headers = {};
    
    if (tab && tab.url) {
      const tabUrl = new URL(tab.url);
      const cookieList = await chrome.cookies.getAll({ domain: tabUrl.hostname });
      if (cookieList.length > 0) {
        cookies = cookieList.map(c => `${c.name}=${c.value}`).join('; ');
      }
      
      headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": navigator.userAgent,
        "Origin": tabUrl.origin,
        "Referer": tab.url
      };
    }
    
    const config = {
      name: name,
      url: url,
      method: method,
      headers: headers,
      cookies: cookies,
      body: '{"email":"{{email}}"}',
      proxy: null,
      createdAt: new Date().toISOString()
    };
    
    currentConfig = config;
    await chrome.storage.local.set({ activeConfig: config });
    
    applyConfig(config);
    showMainApp();
    showConfigStatus('✓ Config created successfully!', 'success');
    
  } catch (error) {
    console.error('Error creating config:', error);
    showConfigStatus('Error: ' + error.message, 'error');
  }
}

// Import cURL to config
async function importCurlToConfig() {
  try {
    const curlCmd = configElements.curlCommand.value.trim();
    if (!curlCmd) {
      showConfigStatus('Please paste a cURL command', 'error');
      return;
    }
    
    const parsed = parseCurlCommand(curlCmd);
    
    const config = {
      name: 'Imported from cURL',
      url: parsed.url,
      method: parsed.method,
      headers: parsed.headers,
      cookies: parsed.cookies || '',
      body: parsed.data || '{"email":"{{email}}"}',
      proxy: null,
      createdAt: new Date().toISOString()
    };
    
    currentConfig = config;
    await chrome.storage.local.set({ activeConfig: config });
    
    applyConfig(config);
    showMainApp();
    showConfigStatus('✓ cURL imported successfully!', 'success');
    
  } catch (error) {
    console.error('Error importing cURL:', error);
    showConfigStatus('Error: ' + error.message, 'error');
  }
}

// Parse cURL command
function parseCurlCommand(curlCmd) {
  const result = {
    url: null,
    method: 'GET',
    headers: {},
    cookies: null,
    data: null
  };
  
  let cmd = curlCmd
    .replace(/\\\n/g, ' ')
    .replace(/\n/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  
  const urlMatch = cmd.match(/curl\s+['"]?([^'"\s]+)['"]?/i) || 
                   cmd.match(/['"]?(https?:\/\/[^'"\s]+)['"]?/);
  if (urlMatch) {
    result.url = urlMatch[1].replace(/^['"]|['"]$/g, '');
  }
  
  const methodMatch = cmd.match(/(?:-X|--request)\s+['"]?(\w+)['"]?/i);
  if (methodMatch) {
    result.method = methodMatch[1].toUpperCase();
  }
  
  const headerRegex = /(?:-H|--header)\s+['"]([^'"]+)['"]/g;
  let headerMatch;
  while ((headerMatch = headerRegex.exec(cmd)) !== null) {
    const headerStr = headerMatch[1];
    const colonIndex = headerStr.indexOf(':');
    if (colonIndex > 0) {
      const key = headerStr.substring(0, colonIndex).trim();
      const value = headerStr.substring(colonIndex + 1).trim();
      if (key.toLowerCase() !== 'cookie') {
        result.headers[key] = value;
      }
    }
  }
  
  const cookieMatch = cmd.match(/(?:-b|--cookie)\s+['"]([^'"]+)['"]/);
  if (cookieMatch) {
    result.cookies = cookieMatch[1];
  }
  
  const dataMatch = cmd.match(/(?:--data-raw|--data-binary|--data|-d)\s+['"](.+?)['"]\s*(?:-|$)/s);
  if (dataMatch) {
    result.data = dataMatch[1].replace(/\\"/g, '"').replace(/\\'/g, "'");
    result.method = 'POST';
  }
  
  return result;
}

// Apply config to UI
function applyConfig(config) {
  if (elements.targetUrl) elements.targetUrl.value = config.url || '';
  if (elements.requestMethod) elements.requestMethod.value = config.method || 'POST';
  if (elements.customHeaders) elements.customHeaders.value = JSON.stringify(config.headers || {}, null, 2);
  if (elements.cookieValue) elements.cookieValue.value = config.cookies || '';
  if (elements.useCookies) elements.useCookies.checked = !!config.cookies;
  if (elements.requestBody) elements.requestBody.value = config.body || '{"email":"{{email}}"}';
  
  // Update config info display - simplified (name only)
  if (configElements.currentConfigInfo) {
    configElements.currentConfigInfo.innerHTML = `
      <strong>${config.name || 'Unnamed Config'}</strong>
    `;
  }
}

// Show/hide sections
function showConfigSetup() {
  if (configElements.configSetup) configElements.configSetup.classList.remove('hidden');
  if (configElements.mainApp) configElements.mainApp.classList.add('hidden');
}

function showMainApp() {
  if (configElements.configSetup) configElements.configSetup.classList.add('hidden');
  if (configElements.mainApp) configElements.mainApp.classList.remove('hidden');
}

// Export current config to .child format
function exportCurrentConfig() {
  if (!currentConfig) {
    alert('No config to export');
    return;
  }
  
  // Convert config to .child format
  let childContent = `NAME: ${currentConfig.name}\n`;
  childContent += `URL: ${currentConfig.url}\n`;
  childContent += `METHOD: ${currentConfig.method}\n`;
  
  if (currentConfig.headers) {
    childContent += `\n# Headers\n`;
    for (const [key, value] of Object.entries(currentConfig.headers)) {
      if (key === 'Content-Type') {
        childContent += `CONTENT_TYPE: ${value}\n`;
      } else {
        childContent += `HEADER_${key}: ${value}\n`;
      }
    }
  }
  
  if (currentConfig.cookieAuto) {
    childContent += `\n# Auto-get cookies from browser\n`;
    childContent += `COOKIE_AUTO: true\n`;
  }
  
  if (currentConfig.body) {
    childContent += `\n# Request body with placeholders\n`;
    childContent += `DATARAW: ${currentConfig.body}\n`;
  }
  
  if (currentConfig.extractRules && Object.keys(currentConfig.extractRules).length > 0) {
    childContent += `\n# Extract value from response for next request\n`;
    for (const [varName, path] of Object.entries(currentConfig.extractRules)) {
      childContent += `EXTRACT_${varName}: ${path}\n`;
    }
  }
  
  if (currentConfig.validRules) {
    childContent += `\n# Validation rules\n`;
    if (currentConfig.validRules.statusRange) {
      childContent += `VALID_IF_STATUS: ${currentConfig.validRules.statusRange}\n`;
    }
    if (currentConfig.validRules.validContains) {
      childContent += `VALID_IF_CONTAINS: ${currentConfig.validRules.validContains.join(',')}\n`;
    }
    if (currentConfig.validRules.invalidContains) {
      childContent += `INVALID_IF_CONTAINS: ${currentConfig.validRules.invalidContains.join(',')}\n`;
    }
  }
  
  const blob = new Blob([childContent], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const filename = currentConfig.name.toLowerCase().replace(/\s+/g, '_');
  a.download = `${filename}.child`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Show config status
function showConfigStatus(message, type) {
  if (!configElements.configStatus) return;
  
  configElements.configStatus.textContent = message;
  configElements.configStatus.classList.remove('hidden', 'status-success', 'status-error');
  
  if (type === 'success') {
    configElements.configStatus.classList.add('status-success');
  } else if (type === 'error') {
    configElements.configStatus.classList.add('status-error');
  }
  
  setTimeout(() => {
    configElements.configStatus.classList.add('hidden');
  }, 3000);
}

// Setup main app event listeners
function setupEventListeners() {
  // Open target website button
  elements.openTargetBtn?.addEventListener('click', openTargetWebsite);
  
  // Email input tabs
  elements.tabPasteEmails?.addEventListener('click', () => switchEmailInputTab('paste'));
  elements.tabUploadFile?.addEventListener('click', () => switchEmailInputTab('upload'));
  
  // Email loading
  elements.loadEmailsBtn?.addEventListener('click', loadEmailsFromText);
  elements.fileUpload?.addEventListener('change', handleFileUpload);
  
  // Other event listeners
  elements.useProxy?.addEventListener('change', toggleProxySettings);
  elements.getCookiesBtn?.addEventListener('click', getCookiesFromTab);
  elements.refreshCookiesBtn?.addEventListener('click', refreshCookiesAndReopen);
  elements.startBtn?.addEventListener('click', startValidation);
  elements.stopBtn?.addEventListener('click', stopValidation);
  elements.exportValid?.addEventListener('click', () => exportEmails('valid'));
  elements.exportInvalid?.addEventListener('click', () => exportEmails('invalid'));
  
  elements.targetUrl?.addEventListener('change', saveSettings);
  elements.useProxy?.addEventListener('change', saveSettings);
  elements.proxyHost?.addEventListener('change', saveSettings);
  elements.proxyPort?.addEventListener('change', saveSettings);
  elements.customHeaders?.addEventListener('change', saveSettings);
  elements.requestMethod?.addEventListener('change', saveSettings);
  elements.requestBody?.addEventListener('change', saveSettings);
}

// Open target website in new tab
async function openTargetWebsite() {
  const url = elements.targetUrl?.value.trim();
  
  if (!url) {
    alert('Please enter target URL first');
    return;
  }
  
  // Validate URL
  try {
    new URL(url);
  } catch (e) {
    alert('Invalid URL format');
    return;
  }
  
  // Extract base URL (without path)
  const urlObj = new URL(url);
  const baseUrl = `${urlObj.protocol}//${urlObj.hostname}`;
  
  // Send message to background to open tab
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'openTargetTab',
      url: baseUrl
    });
    
    if (response.success) {
      const actionText = response.action === 'focused' ? 'Tab focused' : 'Tab created';
      console.log(`✓ ${actionText}: ${baseUrl}`);
      
      // Update button text temporarily
      elements.openTargetBtn.textContent = `✓ ${actionText}`;
      setTimeout(() => {
        elements.openTargetBtn.textContent = '🔗 Open Tab';
      }, 2000);
    } else {
      console.error('Failed to open tab:', response.error);
      alert('Failed to open tab: ' + response.error);
    }
  } catch (error) {
    console.error('Error opening target tab:', error);
    alert('Error: ' + error.message);
  }
}

// Switch between email input tabs
function switchEmailInputTab(tab) {
  // Update tab buttons
  elements.tabPasteEmails?.classList.remove('active');
  elements.tabUploadFile?.classList.remove('active');
  
  if (tab === 'paste') {
    elements.tabPasteEmails?.classList.add('active');
    elements.pasteEmailsArea?.classList.remove('hidden');
    elements.uploadFileArea?.classList.add('hidden');
  } else if (tab === 'upload') {
    elements.tabUploadFile?.classList.add('active');
    elements.pasteEmailsArea?.classList.add('hidden');
    elements.uploadFileArea?.classList.remove('hidden');
  }
}

// Load emails from textarea
function loadEmailsFromText() {
  const text = elements.emailListText?.value.trim();
  if (!text) {
    showNotification('⚠️ Please paste email list first!', 'warning');
    return;
  }
  
  // Show loading indicator
  elements.loadEmailsBtn.disabled = true;
  elements.loadEmailsBtn.textContent = '⏳ Loading...';
  
  // Process emails with slight delay to ensure UI updates
  setTimeout(() => {
  emailList = text.split('\n')
    .map(email => email.trim())
      .filter(email => email.length > 0 && email.includes('@')); // Validate contains @
  
  if (emailList.length === 0) {
      showNotification('❌ No valid emails found! Check format.', 'error');
      elements.loadEmailsBtn.disabled = false;
      elements.loadEmailsBtn.textContent = 'Load Emails';
    return;
  }
    
    console.log(`📧 Loaded ${emailList.length} emails for validation`);
    console.log(`First 5 emails:`, emailList.slice(0, 5));
  
  if (elements.fileInfo) {
      elements.fileInfo.textContent = `✓ Loaded ${emailList.length} emails - Ready to start!`;
    elements.fileInfo.classList.remove('hidden');
  }
  if (elements.totalCount) {
      elements.totalCount.textContent = emailList.length.toString();
  }
  updateProgress(0);
    
    // Enable start button
    if (elements.startBtn) {
      elements.startBtn.disabled = false;
      elements.startBtn.textContent = `▶️ Start Validation (${emailList.length} emails)`;
    }
  
  // Success feedback
    elements.loadEmailsBtn.disabled = false;
  elements.loadEmailsBtn.textContent = '✓ Loaded!';
  setTimeout(() => {
    elements.loadEmailsBtn.textContent = 'Load Emails';
  }, 2000);
  }, 100); // Small delay to ensure sync
}

// Toggle proxy settings
function toggleProxySettings() {
  if (elements.useProxy.checked) {
    elements.proxySettings?.classList.remove('hidden');
  } else {
    elements.proxySettings?.classList.add('hidden');
  }
}

// Handle file upload
function handleFileUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  // Show loading
  if (elements.fileInfo) {
    elements.fileInfo.textContent = '⏳ Loading file...';
    elements.fileInfo.classList.remove('hidden');
  }
  
  const reader = new FileReader();
  reader.onload = (e) => {
    const content = e.target.result;
    
    // Process with delay to ensure complete
    setTimeout(() => {
    emailList = content.split('\n')
      .map(email => email.trim())
        .filter(email => email.length > 0 && email.includes('@'));
      
      console.log(`📧 Loaded ${emailList.length} emails from file`);
      console.log(`First 5 emails:`, emailList.slice(0, 5));
      
      if (elements.fileInfo) {
        elements.fileInfo.textContent = `✓ Loaded ${emailList.length} emails - Ready to start!`;
      }
      if (elements.totalCount) {
        elements.totalCount.textContent = emailList.length.toString();
      }
    updateProgress(0);
      
      // Enable start button
      if (elements.startBtn) {
        elements.startBtn.disabled = false;
        elements.startBtn.textContent = `▶️ Start Validation (${emailList.length} emails)`;
      }
    }, 100);
  };
  reader.readAsText(file);
}

// Get cookies from current tab
async function getCookiesFromTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url) {
      alert('No active tab found');
      return;
    }
    
    const url = new URL(tab.url);
    const cookies = await chrome.cookies.getAll({ domain: url.hostname });
    
    if (cookies.length === 0) {
      elements.cookieValue.value = 'No cookies found for this domain';
      showCookieStatus('⚠️ No cookies found', 'warning');
      return;
    }
    
    const cookieString = cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
    elements.cookieValue.value = cookieString;
    elements.useCookies.checked = true;
    
    // Show cookie info
    const expiringCookies = cookies.filter(c => c.expirationDate && c.expirationDate < (Date.now() / 1000 + 3600));
    let statusMsg = `✓ Retrieved ${cookies.length} cookies from ${url.hostname}`;
    if (expiringCookies.length > 0) {
      statusMsg += ` (${expiringCookies.length} expiring soon!)`;
    }
    showCookieStatus(statusMsg, 'success');
    
    console.log(`Retrieved ${cookies.length} cookies from ${url.hostname}`);
  } catch (error) {
    console.error('Error getting cookies:', error);
    showCookieStatus('Error getting cookies: ' + error.message, 'error');
  }
}

// Refresh cookies by reopening target website
async function refreshCookiesAndReopen() {
  const url = elements.targetUrl?.value.trim();
  
  if (!url) {
    showNotification('⚠️ Please enter target URL first', 'warning');
    return;
  }
  
  // Show instruction via notification
  showNotification('🔄 Opening target website... Please LOGIN there!', 'info', 10000);
  
  try {
    // Extract base URL
    const urlObj = new URL(url);
    const baseUrl = `${urlObj.protocol}//${urlObj.hostname}`;
    
    // Open target tab
    const response = await chrome.runtime.sendMessage({
      action: 'openTargetTab',
      url: baseUrl
    });
    
    if (response.success) {
      showNotification('🔗 Target website opened. Please LOGIN there, then come back!', 'success', 10000);
      
      // Auto-get cookies after delay (no confirm needed)
      setTimeout(async () => {
        showNotification('🍪 Checking for new cookies...', 'info', 3000);
        await getCookiesFromTab();
      }, 8000); // After 8 seconds
    }
  } catch (error) {
    console.error('Error opening target tab:', error);
    alert('Error: ' + error.message);
  }
}

// Show cookie status message
function showCookieStatus(message, type) {
  if (!elements.cookieStatus) return;
  
  elements.cookieStatus.textContent = message;
  elements.cookieStatus.classList.remove('hidden', 'status-success', 'status-error', 'status-warning', 'status-info');
  
  if (type === 'success') {
    elements.cookieStatus.classList.add('status-success');
  } else if (type === 'error') {
    elements.cookieStatus.classList.add('status-error');
  } else if (type === 'warning') {
    elements.cookieStatus.classList.add('status-warning');
  } else if (type === 'info') {
    elements.cookieStatus.classList.add('status-info');
  }
  
  elements.cookieStatus.classList.remove('hidden');
}

// Start validation
async function startValidation() {
  if (!elements.targetUrl.value) {
    showNotification('⚠️ Please enter target URL first!', 'warning');
    return;
  }
  
  if (emailList.length === 0) {
    showNotification('⚠️ Please load email list first!\n\nPaste emails → Load Emails → Wait for "✓ Loaded"', 'warning', 5000);
    return;
  }
  
  // Double-check email list is actually loaded
  console.log(`🚀 Starting validation for ${emailList.length} emails`);
  console.log(`Email list preview:`, emailList.slice(0, 3));
  
  isRunning = true;
  currentIndex = 0;
  validEmails = [];
  invalidEmails = [];
  liveEmails = [];
  bounceEmails = [];
  dieEmails = [];
  liveEmailsData = []; // Reset live data
  
  elements.startBtn.disabled = true;
  elements.stopBtn?.classList.remove('hidden');
  elements.progressText.textContent = 'Running...';
  
  // Concurrent batch size (check X emails at once)
  const concurrentSize = (currentConfig && currentConfig.batchSize) ? currentConfig.batchSize : 5;
  
  // Store original total for progress calculation
  const totalEmails = emailList.length;
  let processedCount = 0;
  
  // Optimized chunked processing for large batches
  while (emailList.length > 0 && isRunning) {
    const i = processedCount;
    const batchSize = Math.min(concurrentSize, emailList.length);
    const batchEmails = [];
    
    for (let j = 0; j < batchSize; j++) {
      batchEmails.push({
        email: emailList[j],
        index: processedCount + j + 1
      });
    }
    
    currentIndex = i;
    const remaining = emailList.length;
    elements.progressText.textContent = `⚡ Processing ${batchSize} emails (${processedCount + 1}-${processedCount + batchSize}/${totalEmails}) | Remaining: ${remaining}`;
    console.log(`⚡ Batch: ${batchSize} emails | Processed: ${processedCount}/${totalEmails} | Remaining: ${remaining}`);
    
    // Optimized: Process in smaller chunks if batch is very large
    const CHUNK_SIZE = 100; // Process max 100 at a time for stability
    
    if (batchSize <= CHUNK_SIZE) {
      // Small batch - process all at once
      const batchPromises = batchEmails.map(item => processEmail(item.email, item.index));
      await Promise.all(batchPromises);
    } else {
      // Large batch - split into chunks for better performance
      for (let chunkStart = 0; chunkStart < batchSize; chunkStart += CHUNK_SIZE) {
        const chunkEnd = Math.min(chunkStart + CHUNK_SIZE, batchSize);
        const chunk = batchEmails.slice(chunkStart, chunkEnd);
        
        console.log(`  → Chunk ${chunkStart}-${chunkEnd-1}: Processing ${chunk.length} emails...`);
        const chunkPromises = chunk.map(item => processEmail(item.email, item.index));
        await Promise.all(chunkPromises);
        
        // Micro update for large batches
        updateProgress(((processedCount + chunkEnd) / totalEmails) * 100);
        
        // Tiny yield to prevent UI freeze
        await new Promise(resolve => setTimeout(resolve, 0));
      }
    }
    
    processedCount += batchSize;
    updateProgress((processedCount / totalEmails) * 100);
  }
  
  if (isRunning) {
    elements.progressText.textContent = 'Completed!';
    
    // Show detailed summary via notification
    const summary = `✅ Validation completed!\n\n✓ Live: ${liveEmails.length} | ⚠ Bounce: ${bounceEmails.length} | ✗ Die: ${dieEmails.length}\n\nTotal Valid: ${validEmails.length} | Invalid: ${invalidEmails.length}`;
    
    showNotification(summary, 'success', 5000);
    console.log('✓ Validation completed:', { live: liveEmails.length, bounce: bounceEmails.length, die: dieEmails.length });
  }
  
  // Always call stopValidation (which will auto-save if there are results)
  stopValidation();
}

// Auto-save live emails with data
function autoSaveLiveEmails() {
  if (liveEmailsData.length === 0) {
    console.log('No live emails to save');
    return;
  }
  
  // Format: email|cashtag|Linked Debit:Yes|Recent Activity:date
  let content = 'email|cashtag|Linked Debit|Recent Activity\n';
  
  for (const data of liveEmailsData) {
    const linkedDebit = data.linkedDebit ? 'Yes' : 'No';
    
    // Convert Unix timestamp to readable date
    let recentActivity = '';
    if (data.recentActivity) {
      try {
        const date = new Date(data.recentActivity * 1000); // Unix to JS timestamp
        recentActivity = date.toISOString().split('T')[0]; // Format: 2025-10-21
        // Or use: date.toLocaleString() for full date-time
      } catch (e) {
        recentActivity = data.recentActivity; // Fallback to raw value
      }
    }
    
    content += `${data.email}|${data.cashtag}|Linked Debit:${linkedDebit}|Recent Activity:${recentActivity}\n`;
  }
  
  // Save to file (downloads to browser Downloads folder)
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  
  // Filename with date for easy organizing
  const now = new Date();
  const dateStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
  const timeStr = `${String(now.getHours()).padStart(2,'0')}${String(now.getMinutes()).padStart(2,'0')}`;
  const configName = (currentConfig && currentConfig.name) ? currentConfig.name.toLowerCase().replace(/\s+/g, '_') : 'result';
  
  a.download = `${configName}_live_${dateStr}_${timeStr}.txt`;
  
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  console.log(`✓ Auto-saved ${liveEmailsData.length} live emails`);
  console.log(`📁 File: ${a.download}`);
  console.log(`📂 Location: Browser Downloads folder`);
  showNotification(`📁 Saved ${liveEmailsData.length} live emails!\n\nFile: ${a.download}\nCheck Downloads folder`, 'success', 8000);
}

// Process single email
async function processEmail(email, number) {
  try {
    // Prepare body with placeholder replacement
    let body = elements.requestBody.value;
    
    // Replace {{email}} placeholder
    body = body.replace(/\{\{email\}\}/g, email);
    
    // Replace extracted values like {{getvalue}}
    for (const [key, value] of Object.entries(extractedValues)) {
      const placeholder = `{{${key}}}`;
      body = body.replace(new RegExp(placeholder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), value);
    }
    
    const config = {
      url: elements.targetUrl.value,
      method: elements.requestMethod.value,
      email: email,
      headers: {},
      body: body,
      proxy: null
    };
    
    if (elements.customHeaders.value.trim()) {
      try {
        config.headers = JSON.parse(elements.customHeaders.value);
      } catch (e) {
        console.error('Invalid JSON in custom headers');
      }
    }
    
    if (elements.useCookies.checked && elements.cookieValue.value) {
      config.headers['Cookie'] = elements.cookieValue.value;
    }
    
    const response = await chrome.runtime.sendMessage({
      action: 'validateEmail',
      config: config
    });
    
    latestResponse = response;
    updateResponseViewer(response);
    
    // Check for authentication/cookie errors
    if (isAuthenticationError(response)) {
      console.error('Authentication error detected:', response.status);
      
      // Just mark as error and continue (no auto-refresh)
      dieEmails.push(email);
      if (elements.dieCount) elements.dieCount.textContent = dieEmails.length;
      invalidEmails.push(email);
      if (elements.invalidCount) elements.invalidCount.textContent = invalidEmails.length;
      addResultItem(email, false, number, 'Access Denied', 'die');
      return;
    }
    
    // Extract values from response if config has extract rules
    if (currentConfig && currentConfig.extractRules) {
      extractValuesFromResponse(response, currentConfig.extractRules);
    }
    
    // Determine validity using custom rules if available
    let validationResult;
    if (currentConfig && currentConfig.validRules) {
      validationResult = determineValidityWithRules(response, currentConfig.validRules);
    } else {
      validationResult = { isValid: determineValidity(response), status: 'unknown' };
    }
    
    const isValid = validationResult.isValid;
    const status = validationResult.status; // 'live', 'die', 'bounce', 'unknown'
    
    // Update counters based on status
    if (status === 'live') {
      liveEmails.push(email);
      
      // Store email with extracted data
      const emailData = {
        email: email,
        cashtag: extractedValues.cashtag || '',
        linkedDebit: extractedValues.linkedDebit || false,
        recentActivity: extractedValues.recentActivity || ''
      };
      liveEmailsData.push(emailData);
      console.log('✓ LIVE saved:', emailData);
      
      if (elements.liveCount) elements.liveCount.textContent = liveEmails.length;
      validEmails.push(email);
      if (elements.validCount) elements.validCount.textContent = validEmails.length;
    } else if (status === 'bounce') {
      bounceEmails.push(email);
      if (elements.bounceCount) elements.bounceCount.textContent = bounceEmails.length;
      validEmails.push(email);
      if (elements.validCount) elements.validCount.textContent = validEmails.length;
    } else if (status === 'die' || !isValid) {
      dieEmails.push(email);
      if (elements.dieCount) elements.dieCount.textContent = dieEmails.length;
      invalidEmails.push(email);
      if (elements.invalidCount) elements.invalidCount.textContent = invalidEmails.length;
    } else {
      // Fallback for 'unknown' status
      if (isValid) {
        validEmails.push(email);
        if (elements.validCount) elements.validCount.textContent = validEmails.length;
      } else {
        invalidEmails.push(email);
        if (elements.invalidCount) elements.invalidCount.textContent = invalidEmails.length;
      }
    }
    
    addResultItem(email, isValid, number, null, status);
    
    // Remove email from list after processing
    removeEmailFromList(email);
    
  } catch (error) {
    console.error('Error processing email:', email, error);
    dieEmails.push(email);
    if (elements.dieCount) elements.dieCount.textContent = dieEmails.length;
    invalidEmails.push(email);
    if (elements.invalidCount) elements.invalidCount.textContent = invalidEmails.length;
    addResultItem(email, false, number, error.message, 'die');
    
    // Remove email even if error
    removeEmailFromList(email);
  }
}

// Remove email from list after checking
function removeEmailFromList(email) {
  // Remove from emailList array
  const index = emailList.indexOf(email);
  if (index > -1) {
    emailList.splice(index, 1);
  }
  
  // Update textarea display
  if (elements.emailListText) {
    elements.emailListText.value = emailList.join('\n');
  }
  
  // Update total counter to show remaining
  if (elements.totalCount) {
    const total = parseInt(elements.totalCount.textContent) || 0;
    elements.totalCount.textContent = total; // Keep original total
  }
}

// Extract values from response based on rules
function extractValuesFromResponse(response, extractRules) {
  if (!response || !response.data) return;
  
  try {
    // Parse response data if it's a string
    const data = typeof response.data === 'string' ? JSON.parse(response.data) : response.data;
    
    // Extract each value based on rules
    for (const [varName, path] of Object.entries(extractRules)) {
      // Simple JSON path extraction (e.g., "flowStateId" or "data.flowStateId")
      const value = getValueByPath(data, path);
      if (value !== undefined) {
        extractedValues[varName] = value;
        console.log(`Extracted ${varName} = ${value}`);
      }
    }
  } catch (error) {
    console.error('Error extracting values:', error);
  }
}

// Get value from object by path
function getValueByPath(obj, path) {
  const keys = path.split('.');
  let current = obj;
  
  for (const key of keys) {
    if (current && typeof current === 'object' && key in current) {
      current = current[key];
    } else {
      return undefined;
    }
  }
  
  return current;
}

// Determine validity with custom rules - returns {isValid, status}
function determineValidityWithRules(response, rules) {
  if (!response) return { isValid: false, status: 'die' };
  
  // Get response text for keyword matching
  // IMPORTANT: Convert object to string for keyword matching
  let responseText = '';
  let responseObj = null;
  
  try {
    if (typeof response.data === 'string') {
      responseText = response.data;
      try {
        responseObj = JSON.parse(response.data);
  } catch (e) {
        // Not JSON, use as text
      }
    } else if (typeof response.data === 'object') {
      // Data is already object - stringify it for keyword matching
      responseText = JSON.stringify(response.data);
      responseObj = response.data;
    }
  } catch (e) {
    console.error('Error processing response:', e);
    responseText = '';
  }
  
  // Log response for debugging
  console.log('Response type:', typeof response.data);
  console.log('Response text (first 300 chars):', responseText.substring(0, 300));
  if (responseObj) {
    console.log('Response object:', responseObj);
  }
  
  // === DETAILED DETECTION LOGGING ===
  console.log('━━━ DETECTION START ━━━');
  
  // Check DIE keywords (invalid email)
  console.log('1️⃣ Checking DIE keywords:', rules.dieContains);
  if (rules.dieContains && rules.dieContains.length > 0) {
    for (const keyword of rules.dieContains) {
      const found = responseText.includes(keyword);
      console.log(`   DIE keyword "${keyword}": ${found ? '✗ FOUND' : '○ not found'}`);
      if (found) {
        console.log('━━━ RESULT: ✗ DIE ━━━');
        return { isValid: false, status: 'die' };
      }
    }
  }
  console.log('   ✓ No DIE keywords matched');
  
  // Check BOUNCE keywords (valid but suspended/blocked)
  console.log('2️⃣ Checking BOUNCE keywords:', rules.bounceContains);
  if (rules.bounceContains && rules.bounceContains.length > 0) {
    for (const keyword of rules.bounceContains) {
      const found = responseText.includes(keyword);
      console.log(`   BOUNCE keyword "${keyword}": ${found ? '⚠ FOUND' : '○ not found'}`);
      if (found) {
        console.log('━━━ RESULT: ⚠ BOUNCE ━━━');
        return { isValid: true, status: 'bounce' };
      }
    }
  }
  console.log('   ✓ No BOUNCE keywords matched');
  
  // Check LIVE keywords (valid and active)
  console.log('3️⃣ Checking LIVE keywords:', rules.liveContains);
  if (rules.liveContains && rules.liveContains.length > 0) {
    for (const keyword of rules.liveContains) {
      const found = responseText.includes(keyword);
      console.log(`   LIVE keyword "${keyword}": ${found ? '✓ FOUND' : '○ not found'}`);
      if (found) {
        console.log('━━━ RESULT: ✓ LIVE ━━━');
        return { isValid: true, status: 'live' };
      }
    }
  }
  console.log('   ⚪ No LIVE keywords matched');
  
  console.log('4️⃣ Falling back to other rules...');
  
  // Fallback: check old-style rules if present
  if (rules.invalidContains && rules.invalidContains.length > 0) {
    for (const keyword of rules.invalidContains) {
      if (responseText.toLowerCase().includes(keyword.toLowerCase())) {
        console.log(`✗ Invalid fallback: keyword "${keyword}" found`);
        return { isValid: false, status: 'die' };
      }
    }
  }
  
  if (rules.validContains && rules.validContains.length > 0) {
    for (const keyword of rules.validContains) {
      if (responseText.toLowerCase().includes(keyword.toLowerCase())) {
        console.log(`✓ Valid fallback: keyword "${keyword}" found`);
        return { isValid: true, status: 'live' }; // Changed from 'unknown' to 'live'
      }
    }
  }
  
  // Check status range
  if (rules.statusRange) {
    const [min, max] = rules.statusRange.split('-').map(s => parseInt(s.trim()));
    if (response.status >= min && response.status <= max) {
      console.log(`✓ Status ${response.status} in range ${min}-${max}`);
      return { isValid: true, status: 'live' }; // Changed from 'unknown' to 'live'
    }
    console.log(`✗ Status ${response.status} outside range ${min}-${max}`);
    return { isValid: false, status: 'die' };
  }
  
  // Default: valid if status is 2xx
  const isValid = response.status >= 200 && response.status < 300;
  console.log(`${isValid ? '✓' : '✗'} Default check: status ${response.status} = ${isValid ? 'valid' : 'invalid'}`);
  return { isValid: isValid, status: isValid ? 'live' : 'die' }; // Changed 'unknown' to 'live'
}

// Determine validity
function determineValidity(response) {
  if (!response || response.error) return false;
  
  if (response.status >= 200 && response.status < 300) {
    try {
      const body = typeof response.data === 'string' ? 
        JSON.parse(response.data) : response.data;
      
      if (body.valid === true || body.status === 'valid' || body.exists === true) {
        return true;
      }
      if (body.valid === false || body.status === 'invalid' || body.exists === false) {
        return false;
      }
      
      return true;
    } catch (e) {
      return response.status === 200;
    }
  }
  
  return false;
}

// Add result item
function addResultItem(email, isValid, number, errorMsg = null, status = 'unknown') {
  const item = document.createElement('div');
  
  // Add status-specific class
  let statusClass = '';
  let statusText = '';
  
  if (status === 'live') {
    statusClass = 'status-live';
    statusText = '✓ LIVE';
  } else if (status === 'bounce') {
    statusClass = 'status-bounce';
    statusText = '⚠ BOUNCE';
  } else if (status === 'die' || !isValid) {
    statusClass = 'status-die';
    statusText = errorMsg ? '✗ ERROR' : '✗ DIE';
  } else {
    statusClass = isValid ? 'valid' : 'invalid';
    statusText = isValid ? 'VALID' : 'INVALID';
  }
  
  item.className = `result-item ${statusClass}`;
  
  const emailSpan = document.createElement('span');
  emailSpan.className = 'email';
  emailSpan.textContent = `${number}. ${email}`;
  
  const statusSpan = document.createElement('span');
  statusSpan.className = 'status';
  statusSpan.textContent = statusText;
  
  item.appendChild(emailSpan);
  item.appendChild(statusSpan);
  
  elements.results?.insertBefore(item, elements.results.firstChild);
}

// Update response viewer
function updateResponseViewer(response) {
  if (!elements.responseContent) return;
  
  if (!response) {
    elements.responseContent.textContent = 'No response';
    return;
  }
  
  const formatted = {
    status: response.status,
    statusText: response.statusText,
    headers: response.headers,
    data: response.data
  };
  
  elements.responseContent.textContent = JSON.stringify(formatted, null, 2);
}

// Update progress
function updateProgress(percent) {
  if (elements.progressFill) elements.progressFill.style.width = percent + '%';
  // Progress text updated in validation loop with remaining count
}

// Stop validation
function stopValidation() {
  isRunning = false;
  elements.startBtn.disabled = false;
  elements.stopBtn?.classList.add('hidden');
  
  // Auto-save results when stopped (not just on complete)
  if (liveEmailsData.length > 0) {
    console.log('⏹️ Validation stopped - auto-saving results...');
    autoSaveLiveEmails();
    
    // Show summary when stopped
    const summary = `⏹️ Validation stopped!\n\n✓ Live: ${liveEmails.length} | ⚠ Bounce: ${bounceEmails.length} | ✗ Die: ${dieEmails.length}\n\n📁 Results saved to Downloads!`;
    showNotification(summary, 'warning', 8000);
  }
}

// Clear results function removed - not needed
// Results auto-clear when loading new emails

// Export emails
function exportEmails(type) {
  const emails = type === 'valid' ? validEmails : invalidEmails;
  
  if (emails.length === 0) {
    showNotification(`⚠️ No ${type} emails to export!`, 'warning');
    return;
  }
  
  const blob = new Blob([emails.join('\n')], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${type}_emails_${Date.now()}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  showNotification(`✅ Exported ${emails.length} ${type} emails!`, 'success');
}

// Save settings
function saveSettings() {
  const settings = {
    targetUrl: elements.targetUrl?.value,
    useProxy: elements.useProxy?.checked,
    proxyHost: elements.proxyHost?.value,
    proxyPort: elements.proxyPort?.value,
    customHeaders: elements.customHeaders?.value,
    requestMethod: elements.requestMethod?.value,
    requestBody: elements.requestBody?.value
  };
  
  chrome.storage.local.set({ settings });
}

// Load settings
function loadSettings() {
  chrome.storage.local.get(['settings'], (result) => {
    if (result.settings && elements.targetUrl) {
      const s = result.settings;
      elements.targetUrl.value = s.targetUrl || '';
      if (elements.useProxy) elements.useProxy.checked = s.useProxy || false;
      if (elements.proxyHost) elements.proxyHost.value = s.proxyHost || '';
      if (elements.proxyPort) elements.proxyPort.value = s.proxyPort || '';
      if (elements.customHeaders) elements.customHeaders.value = s.customHeaders || '';
      if (elements.requestMethod) elements.requestMethod.value = s.requestMethod || 'POST';
      if (elements.requestBody) elements.requestBody.value = s.requestBody || '{"email": "{{email}}"}';
      
      if (s.useProxy && elements.proxySettings) {
        elements.proxySettings.classList.remove('hidden');
      }
    }
  });
}

// Check if response is authentication/cookie error
function isAuthenticationError(response) {
  if (!response) return false;
  
  // Check status codes
  if (response.status === 401 || response.status === 403) {
    return true;
  }
  
  // Check response content for common auth error patterns
  if (response.data) {
    const dataStr = typeof response.data === 'string' ? 
      response.data.toLowerCase() : 
      JSON.stringify(response.data).toLowerCase();
    
    const authErrorPatterns = [
      'access denied',
      'unauthorized',
      'authentication required',
      'cookie expired',
      'session expired',
      'invalid session',
      'permission denied',
      'forbidden',
      'akamaighost',
      'reference #'
    ];
    
    for (const pattern of authErrorPatterns) {
      if (dataStr.includes(pattern)) {
        return true;
      }
    }
  }
  
  return false;
}

// Auto-refresh target website when access denied
async function autoRefreshTargetWebsite() {
  try {
    const targetUrl = elements.targetUrl?.value.trim();
    if (!targetUrl) return;
    
    // Extract base URL
    const urlObj = new URL(targetUrl);
    const baseUrl = `${urlObj.protocol}//${urlObj.hostname}`;
    
    // Find target website tab
    const tabs = await chrome.tabs.query({});
    const targetTab = tabs.find(tab => tab.url && tab.url.includes(urlObj.hostname));
    
    if (targetTab) {
      // Refresh existing tab
      console.log(`🔄 Refreshing target website: ${baseUrl}`);
      await chrome.tabs.reload(targetTab.id);
      
      // Show notification
      showCookieStatus('🔄 Target website auto-refreshed! Continuing...', 'info');
      
      // Wait for page to reload
      await sleep(2000);
    } else {
      // Open new tab if not exists
      console.log(`🔗 Opening target website: ${baseUrl}`);
      await chrome.runtime.sendMessage({
        action: 'openTargetTab',
        url: baseUrl
      });
      
      showCookieStatus('🔗 Target website opened. Continuing...', 'info');
      await sleep(2000);
    }
    
  } catch (error) {
    console.error('Error refreshing target website:', error);
  }
}

// Helper sleep function
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
