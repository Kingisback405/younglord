DOWNLOADS FOLDER
================

Chrome Extension TIDAK BISA save langsung ke folder spesifik karena security.

File hasil validation akan OTOMATIS DOWNLOAD ke:
📂 Browser Downloads Folder

Filename format:
afterpay_live_2025-10-21_1730.txt

Format:
[config-name]_live_[date]_[time].txt

Contoh:
- afterpay_live_2025-10-21_1430.txt
- xfinity_live_2025-10-22_0915.txt

Location:
Linux: ~/Downloads/
Windows: C:\Users\[user]\Downloads\
Mac: ~/Downloads/

Tips:
- Files auto-organize by date
- Easy to find by config name
- Move to RESULT folder manually if needed
